#!/usr/bin/env groovy

/**
 * @ Maintainer Sudheer Veeravalli <Sudheer.Veeravalli@quest-global.com>
 */

/* Only keep the 20 most recent builds. */
def projectProperties = [
  buildDiscarder(logRotator(artifactDaysToKeepStr: '20', artifactNumToKeepStr: '20', daysToKeepStr: '20', numToKeepStr: '20')),
  disableConcurrentBuilds(),
  pipelineTriggers([pollSCM('H/10 * * * *')])
]

properties(projectProperties)

try {
  node {
      def appName = "MediConnekt"                  // main application name
      def appEnv = 'DEV'                           // application environment
      def appClientName = 'mediconnekt-web'        // application client name
      def appClientExtension = "tar"               // extension of the client artifact
      def appServiceName = 'SpringBoxter'          // application service name
      def appServiceExtension = "jar"              // extension of the service artifact
      //def artifactoryRepoName = 'Quest-DevOps'     // repo name in artifactory
      //def artifactoryAppName = appName             // application name as per artifactory
      def buildNumber = env.BUILD_NUMBER           // jenkins build number - used to tag the docker image/container(s)

      def sonarHome

      def tomcatStackName = 'mediconnekt-dev-tomcat'
      def dockerImageName = 'mediconnekt-dev-image'

      // Mail send syntax
      // mail bcc: '', body: 'Hi -- Body', cc: 'xxx.yyy@quest-global.com', from: 'no-reply@quest-global.com', replyTo: 'no-reply@quest-global.com', subject: 'hi', to: 'xxx.yyy@quest-global.com'

    stage('Tools Setup') {
      // These tools must be configured in the jenkins global/tools configuration.
      try {
        if (isUnix()) {
          sh "echo 'Running in Unix mode'"
        }
        mvnHome = tool name: 'mvn3', type: 'maven'
        sonarHome = tool name: 'sonar-scanner-3.0.3.778', type: 'hudson.plugins.sonar.SonarRunnerInstallation'
        ansible = tool name: 'ansible-2.0.0.2', type: 'org.jenkinsci.plugins.ansible.AnsibleInstallation'
      } catch (exc) {
        error "Failure in Tool Setup stage: ${exc}"
      }
    }

    stage('Checkout / Update') {
      try {
        // Update Client->Web code from repository
        checkout([$class: 'SubversionSCM', additionalCredentials: [], excludedCommitMessages: '', excludedRegions: '', excludedRevprop: '', excludedUsers: '', filterChangelog: false, ignoreDirPropChanges: false, includedRegions: '', locations: [[credentialsId: '1e4205cc-503d-4c7f-a304-2a5ae8174be6', depthOption: 'infinity', ignoreExternalsOption: true, local: './Web/', remote: 'https://intvmsvn01.quest-global.com/svn/TEG/trunk/TED Projects/DevOps/Dev Ops for Mediconnekt/Source/Client/Web']], workspaceUpdater: [$class: 'UpdateUpdater']])

        // Checkout Service code from repository
        checkout([$class: 'SubversionSCM', additionalCredentials: [], excludedCommitMessages: '', excludedRegions: '', excludedRevprop: '', excludedUsers: '', filterChangelog: false, ignoreDirPropChanges: false, includedRegions: '', locations: [[credentialsId: '1e4205cc-503d-4c7f-a304-2a5ae8174be6', depthOption: 'infinity', ignoreExternalsOption: true, local: './Service/', remote: 'https://intvmsvn01.quest-global.com/svn/TEG/trunk/TED Projects/DevOps/Dev Ops for Mediconnekt/Source/Server']], workspaceUpdater: [$class: 'UpdateUpdater']])

        // Checkout docker files repository
        checkout([$class: 'SubversionSCM', additionalCredentials: [], excludedCommitMessages: '', excludedRegions: '', excludedRevprop: '', excludedUsers: '', filterChangelog: false, ignoreDirPropChanges: false, includedRegions: '', locations: [[credentialsId: '1e4205cc-503d-4c7f-a304-2a5ae8174be6', depthOption: 'infinity', ignoreExternalsOption: true, local: './docker_files/', remote: 'https://intvmsvn01.quest-global.com/svn/TEG/trunk/TED Projects/DevOps/Dev Ops for Mediconnekt/Configuration_Files/docker_files']], workspaceUpdater: [$class: 'UpdateUpdater']])

        // Checkout ansible files repository
        checkout([$class: 'SubversionSCM', additionalCredentials: [], excludedCommitMessages: '', excludedRegions: '', excludedRevprop: '', excludedUsers: '', filterChangelog: false, ignoreDirPropChanges: false, includedRegions: '', locations: [[credentialsId: '1e4205cc-503d-4c7f-a304-2a5ae8174be6', depthOption: 'infinity', ignoreExternalsOption: true, local: './ansible_files/', remote: 'https://intvmsvn01.quest-global.com/svn/TEG/trunk/TED Projects/DevOps/Dev Ops for Mediconnekt/Configuration_Files/ansible_files']], workspaceUpdater: [$class: 'UpdateUpdater']])

      } catch (exc) {
        error "Failure in Checkout stage: ${exc}"
      }
    }

    stage('Build') {
      try {
        // Build Service Code
        dir('Service/') {
          sh "'${mvnHome}/bin/mvn' clean package"
          sh "cp ./target/swagger-spring*.jar ./target/${appServiceName}.${appServiceExtension}"
        }

        // Build Web Code
        dir('Web/') {
          sh "rm -rf ${appClientName}/ || exit 0 "
          sh "grunt build -f"
          sh "mv dist/ ${appClientName}/"
          sh "tar cf ${appClientName}.${appClientExtension} ${appClientName}/"

          // copy to respective folders for deployment at later stage
          sh "cp ${appClientName}.${appClientExtension} ../docker_files/"
          sh "cp ${appClientName}.${appClientExtension} ../ansible_files/"
        }
      } catch (exc) {
        error "Failure in Build stage: ${exc}"
      }
    }

    stage('Analysis') {
      try {
        // Analyze Service Code
        dir('Service/') {
          sh "'${mvnHome}/bin/mvn' -P metrics pmd:pmd sonar:sonar"
        }

        // Analyze Web Code
        dir('Web/') {
          // TODO: Write code to analyze web application
        }
      } catch (exc) {
        error "Failure in Analysis stage: ${exc}"
      }
    }

    stage('Deploy on Docker Containers') {
      try {
        // Code to deploy web application into docker swarm
        dir('docker_files/') {
          // Stop and remove existing stacks if any
          sh "docker stack rm ${tomcatStackName} || exit 0"
          sh "sleep 10s"

          // Force remove any previous images from previous builds - $3 corresponds to image id
          sh "docker images | grep ${dockerImageName} | awk '{print \$3}' | xargs docker rmi -f || exit 0"

          // Create LastDeployed.html file
          def startDate = new Date()
          formattedDTTM = startDate.format("yyyy-MM-dd HH:mm:ss")
          sh "echo '<h2> Last Deployed Time = ${formattedDTTM} </br> by Build Number = ${buildNumber} </h2>' > LastDeployed.html"

          // Create Image using the new artfiacts and tag with the current build number
          sh "docker build -t 127.0.0.1:5000/${dockerImageName}:${buildNumber} ."

          // Deploy the stack
          sh "export BUILD_NUMBER=${buildNumber}" // maps to image tag in docker-compose.yml
          sh "docker stack deploy --compose-file docker-compose.yml ${tomcatStackName}"
        }
      } catch (exc) {
        error "Failure during Deployment on Docker Containers stage: ${exc}"
      }
    }

    stage('Deploy on VMs') {
      try {
        // Code to deploy web application on VM's
        dir('ansible_files/') {
          sh "ansible-playbook deploy-on-dev.yml -i mediconnekt_hosts"
          //ansiblePlaybook installation: 'ansible-2.0.0.2', inventory: 'mediconnekt_hosts', playbook: 'deploy-on-dev.yml'
        }

      } catch (exc) {
        error "Failure during Deploy on VMs stage: ${exc}"
      }
    }

    stage('Reporting') {
      try {
        junit '**/Service/target/surefire-reports/*.xml'
        pmd defaultEncoding: '', healthy: '100', pattern: '**/Service/target/pmd.xml', unHealthy: '300', useStableBuildAsReference: false

        // publishHTML([allowMissing: false, alwaysLinkToLastBuild: false, keepAll: false, reportDir: 'Service/target/TestReport', reportFiles: 'index.html', reportName: 'JUnit Report', reportTitles: ''])
      } catch (exc) {
          error "Failure in Reporting stage: ${exc}"
      }
    }

    stage('Clean Up') {
      try {
        // Clean up unwanted files created during the entire build
      } catch (exc) {
        error "Failure in Clean Up stage: ${exc}"
      }
    }
  }
} catch (exc) {
  error "Caught: ${exc}"
}
