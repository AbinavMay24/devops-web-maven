# Details about each configuration file

> This file details all the configuration files used for this application to implement DevOps
> **MediConnekt-DEV-Jenkinsfile.groovy** => Jenkins Pipeline file for DEV environment, allows to write Pipeline as Code.



> **Plugins_For_Jenkins.txt** => All the plugins installed in Jenkins Server
